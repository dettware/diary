This project was made by NLA Swifty/Dettware and if used in any video/pictures on social media it must be credited 
in some way unless given permission. 


You can reach out to me by emailing me at - crazymageisback@gmail.com
Anyway thank you for downloading this project and let me know if you want any changes!